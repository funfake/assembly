int main(void) {
    int test0 = 1;
    char test12 = 'c';
    double testte;

    return 0;
}